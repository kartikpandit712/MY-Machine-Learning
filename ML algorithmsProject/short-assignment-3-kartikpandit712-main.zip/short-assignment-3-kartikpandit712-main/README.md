# Short Assignment 3

**Due: Friday, November 4 @ 11:59 PM**

Find the assignment description in the file "Short Assignment 3.ipynb".

The complete rubric for this assignment can be found in the Canvas page under [Assignments -> Short Assignment 3](https://ufl.instructure.com/courses/464118/assignments/5420931).

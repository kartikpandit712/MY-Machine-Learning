
# Homework 2 Part 2

**Due: Wednesday, October 26 @ 11:59 PM**

Find the assignment description in the file "Homework 2 Part 2.ipynb".

The complete rubric for this assignment can be found in the Canvas page under [Assignments -> Homework 2 Part 2](https://ufl.instructure.com/courses/464118/assignments/5410808).
